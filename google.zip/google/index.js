
let btn = document.querySelector('#searchButton');

btn.addEventListener('click', async () => {

	const userInput = document.querySelector('#userInput').value;

const url = `https://google-web-search1.p.rapidapi.com/?query=${userInput}&limit=20&related_keywords=true`;

const options = {
	method: 'GET',
	headers: {
		'X-RapidAPI-Key': '1d60f169a4mshcbe7b9f4fa984e3p1fdfbfjsn5923ed352302',
		'X-RapidAPI-Host': 'google-web-search1.p.rapidapi.com'
	}
};

try {
	const response = await fetch(url, options);
	const result = await response.json();
	console.log(result.results);

	const mainResult = result.results;

	mainResult.map((cval,i)=>{

		document.querySelector('#result').innerHTML += `
		
		<div id="resultDiv"> 

		<h4><a href="${cval.url}">${cval.title} </a></h4>
		<p>${cval.description}</p>

		</div>`
					
		
	})


} catch (error) {
	console.error(error);
}

})



